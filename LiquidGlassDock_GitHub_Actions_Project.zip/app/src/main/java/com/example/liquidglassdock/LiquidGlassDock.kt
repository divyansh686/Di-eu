package com.example.liquidglassdock

import android.graphics.RenderEffect
import android.graphics.Shader
import android.os.Build
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView

class LiquidGlassDock(private val root: View) {

    private val selection = root.findViewById<View>(R.id.dockSelection)

    private val items = listOf(
        root.findViewById<View>(R.id.dockItem1),
        root.findViewById<View>(R.id.dockItem2),
        root.findViewById<View>(R.id.dockItem3),
        root.findViewById<View>(R.id.dockItem4)
    )

    private val icons = listOf(
        root.findViewById<ImageView>(R.id.dockIcon1),
        root.findViewById<ImageView>(R.id.dockIcon2),
        root.findViewById<ImageView>(R.id.dockIcon3),
        root.findViewById<ImageView>(R.id.dockIcon4)
    )

    fun select(index: Int) {
        if (index !in items.indices) return

        root.post {
            val target = items[index]
            val params = selection.layoutParams as FrameLayout.LayoutParams
            params.gravity = Gravity.BOTTOM or Gravity.START
            params.width = dp(58)
            params.height = dp(44)
            params.leftMargin = target.left + dp(7)
            params.bottomMargin = dp(10)
            selection.layoutParams = params
        }

        icons.forEachIndexed { i, icon ->
            val selected = i == index
            icon.alpha = if (selected) 1f else 0.72f
            icon.scaleX = if (selected) 1.06f else 1f
            icon.scaleY = if (selected) 1.06f else 1f
        }
    }

    fun enableBlurIfSupported() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            root.findViewById<View>(R.id.dockGlassBackground).setRenderEffect(
                RenderEffect.createBlurEffect(
                    18f, 18f, Shader.TileMode.CLAMP
                )
            )
        }
    }

    private fun dp(value: Int): Int =
        (value * root.resources.displayMetrics.density).toInt()
}
