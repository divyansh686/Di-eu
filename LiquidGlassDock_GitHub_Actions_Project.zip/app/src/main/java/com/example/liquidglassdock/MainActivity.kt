package com.example.liquidglassdock

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val dock = LiquidGlassDock(findViewById(R.id.liquidGlassDock))
        dock.enableBlurIfSupported()
        dock.select(0)

        findViewById<android.view.View>(R.id.dockItem1).setOnClickListener {
            dock.select(0)
            Toast.makeText(this, "Dock item 1", Toast.LENGTH_SHORT).show()
        }
        findViewById<android.view.View>(R.id.dockItem2).setOnClickListener {
            dock.select(1)
            Toast.makeText(this, "Dock item 2", Toast.LENGTH_SHORT).show()
        }
        findViewById<android.view.View>(R.id.dockItem3).setOnClickListener {
            dock.select(2)
            Toast.makeText(this, "Dock item 3", Toast.LENGTH_SHORT).show()
        }
        findViewById<android.view.View>(R.id.dockItem4).setOnClickListener {
            dock.select(3)
            Toast.makeText(this, "Dock item 4", Toast.LENGTH_SHORT).show()
        }
    }
}
